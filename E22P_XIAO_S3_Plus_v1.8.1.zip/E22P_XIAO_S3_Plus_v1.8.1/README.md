# E22P-868M30S + XIAO ESP32-S3 Plus – płytka v1.8.1

Płytka dwuwarstwowa FR4 1,6 mm, 40 × 73 mm. Pliki: `E22P_XIAO_S3_Plus.kicad_pro` / `.kicad_pcb` (KiCad 8).

## Układ (od góry)
- **J1 – SMA Amphenol 132289** (płytka 0,062"/1,6 mm) na osi. Kołnierz 9,52 × 1,65 mm siedzi we wcięciu
  **9,8 × 1,6 mm** – czoło kołnierza wystaje ok. 0,05 mm, czyli praktycznie równo z krawędzią płytki.
  Dzięki temu ścianka wspornika z PETG (katalog `wspornik/`) opiera się o kołnierz, a nakrętka SMA dociska
  ściankę do kołnierza. Boki wcięcia mają pola GND do przylutowania boków kołnierza; po lutowaniu złącze
  można dodatkowo zalać klejem z obu stron (nie na gwint).

## Wspornik SMA (`wspornik/`)
`wspornik_sma.scad` (OpenSCAD, parametry na górze), `wspornik_sma.stl` (gotowy do druku), `make_stl.py`.
Ścianka 40 × 14 × 3 mm przed krawędzią płytki, otwór Ø6,6 na gwint (oś 0,4 mm nad górną powierzchnią płytki),
dwie łapy 9 × 7 × 3 mm na płytce przykręcane M3 przez H1/H2 (nakrętki od spodu), dwa żebra.
Gwint zajęty: ścianka 3,0 + podkładka 0,5 + nakrętka 1,6 mm – zostaje ok. 4,5 mm na nakrętkę anteny.
Druk: PETG, ścianką na stole, min. 4 obrysy / 100% wypełnienia. Nakrętkę SMA dokręcać z wyczuciem.
Kolejność: lutowanie złącza → wspornik (śruby M3) → nakrętka SMA → klej → antena.
- **U1 – E22P-868M30S** (SMD). Pady 3,75 × 1,5 mm: 1,25 mm pod modułem i **2,5 mm wystające na zewnątrz**,
  żeby wygodnie podać cynę grotem przy półotworach. Pod modułem na F.Cu
  pełna masa (ekran) zszyta przelotkami z masą na B.Cu.
- **U2 – XIAO ESP32-S3 Plus na goldpinach** 5 mm pod E22P, USB-C wystaje za dolną krawędź.
  Pod XIAO wycięcie 12,9 × 16 mm na radiator (klejony taśmą od spodu XIAO). Pady spodnie XIAO nieużywane.

## Tor antenowy
Pin 21 (ANT) → przelotka → **B.Cu pod E22P** → przelotka → pad środkowy SMA. Długość ok. 17 mm.
- Linia GCPW (koplanarna z masą): **ścieżka 1,2 mm, szczelina 0,2 mm**, masa obok na całej szerokości
  (strefa GND), odniesienie: masa F.Cu pod modułem. Wg wzoru Wadella ok. 50,6 Ω przy εr 4,5 i rdzeniu 1,55 mm.
- Płot z przelotek GND po obu stronach toru co ok. 1,3 mm, wieniec przelotek przy obu przejściach.
- Jeśli fabryka poda inny εr / grubość, sprawdź szerokość w kalkulatorze KiCad (Coplanar w/ ground):
  przy εr 4,2 wystarczy ok. 1,3 mm.

## Zasilanie
XIAO 5V → strefa +5V na F.Cu (lewy pas) → C2 10 µF, C1 100 nF, C3 470 µF / 16 V polimer → piny 9 i 10 E22P.
Minusy kondensatorów do masy B.Cu. C3: Ø10 mm, raster 5,0 mm (8 mm / 3,5 mm też wejdzie po odgięciu nóżek).
Na tej płytce nie ma adaptera Bikemana, więc 100 nF (C1) jest osobnym elementem THT. C1 i C2 stoją tuż przy
pinach 9/10; C3 Ø10 mm nie mieści się obok modułu przy szerokości 40 mm, stoi przy narożniku modułu
(ok. 9 mm od pinów VCC, łączy go szerokie pole miedzi 5 V, a przewody z XIAO dochodzą tą samą miedzią).

## Zasilanie bez USB (J3)
Dwa otwory Ø1,3 mm (pad 2,6 mm, raster 3,5 mm) obok C3: **+5V** (kwadratowy) i **GND** – na przewód 0,5 mm²,
lutowany od spodu. +5V idzie tą samą miedzią co z XIAO, więc zasila jednocześnie E22P (przez C1–C3) i XIAO
przez jego pin 5V. Nie podłączaj jednocześnie USB i zasilacza na J3 (pin 5V XIAO to linia VBUS z USB);
jeśli oba mogą być wpięte, wstaw w przewód +5V diodę Schottky'ego.

## Masa
XIAO ma na listwach tylko jeden pin GND (pady GND na spodzie XIAO zasłania radiator), dlatego ten pin i
GND na J3 mają pełne połączenie ze strefami masy na obu warstwach (bez odciążeń termicznych).
Wszystkie 9 padów GND modułu E22P są połączone z masą pod modułem. Prąd nadawania E22P (do ok. 0,7 A)
płynie przez C3 i masę płytki, nie przez XIAO. Lutując pin GND XIAO, grzej dłużej (duża miedź).

## Połączenia (zgodne z wariantem E22P-868M30S_XIAO-ESP32S3-PLUS_DIV)
| E22P | Sieć | XIAO |
|---|---|---|
| 15 NRST | LORA_NRST | D0 (GPIO1) |
| 13 DIO1 | LORA_DIO1 | D1 (GPIO2) |
| 19 NSS | LORA_NSS | D2 (GPIO3) |
| 6 EN | LORA_EN + R1 10k THT do GND (przy pinie 6) | D3 (GPIO4) |
| 14 BUSY | LORA_BUSY | D7 (GPIO44) |
| 18 SCK | LORA_SCK | D8 (GPIO7) |
| 16 MISO | LORA_MISO | D9 (GPIO8) |
| 17 MOSI | LORA_MOSI | D10 (GPIO9) |
| 7 T/R CTRL + 8 DIO2 | mostek ścieżką | – |
| 9, 10 VCC | +5V | 5V |
| 21 ANT | RF_ANT | J1 SMA |

J2 – czujnik **SHT31** (adres 0x44): **gniazdo żeńskie kątowe 1×4, raster 2,54** przy prawej krawędzi, obok XIAO.
Kolejność od góry jak na module: **VIN (3V3), GND, SCL (D5), SDA (D4)**. Moduł wsuwa się swoimi goldpinami
poziomo, czujnikiem do góry, i wystaje poza płytkę (z dala od ciepła XIAO i E22P). Piny ADR/ALR modułu
zostają wolne. VIN zasilany z 3V3 XIAO.

J4 – **D6 / GPIO43** wyprowadzony na otwór Ø1,0 mm (pad 2,2 mm) na przewód do 0,35 mm², obok XIAO.
Uwaga: GPIO43 to UART0 TX – przy starcie ROM ESP32-S3 wypisuje na nim log, więc sterowane urządzenie
musi tolerować krótkie przebiegi przy włączeniu (albo mieć opóźnione/zatrzaskiwane wejście). Poziom 3,3 V.

## Lutowanie
Pady minusowe (GND) kondensatorów są powiększone: C1 i C2 Ø2,4 mm, C3 Ø3,0 mm, z odciążeniami
termicznymi (4 mostki), żeby dało się je wylutować zwykłą lutownicą i odsysaczem.
Lutowane są wszystkie 22 pady E22P (9 z nich to GND) i wszystkie 14 goldpinów XIAO (D6 nie ma połączenia,
lutuje się go tylko mechanicznie). R1 to rezystor osiowy 1/4 W (raster 7,62 mm) leżący obok pinu 6 modułu.

## Do sprawdzenia przed zamówieniem
1. **Footprint E22P** przyjęty jak E22-900M30S (38,5 × 24 mm, rzędy 24,0 mm, raster 2,54, przerwa 7,6 mm
   między pinami 3-4 i 19-20). Wymiary odczytane z płytki referencyjnej z E22-900M30S. Porównaj z rysunkiem
   z instrukcji E22P lub przyłóż wydruk 1:1.
2. **Złącze SMA**: wymiary wg rysunku Amphenol 132289 rev. A (`NOTCH_W`, `NOTCH_D` w `gen.py`).
3. **Radiator**: maks. ok. 12,5 × 15,5 mm, żeby przeszedł przez wycięcie.

## Dokończenie w KiCad
1. Otwórz `.kicad_pro`, w edytorze PCB naciśnij **B** (wypełnienie stref – plik ma strefy niewypełnione).
2. Uruchom DRC. Projekt nie ma schematu, więc **nie** używaj „Update PCB from Schematic” (usunęłoby sieci).
3. File → Plot → Gerber + Drill (katalog `gerber/` jest już ustawiony).

## Pliki źródłowe
`gen.py` generuje płytkę (wszystkie wymiary jako parametry na górze pliku), `stitch.py` rozmieszcza
przelotki GND, `check.py` symuluje wypełnienie stref, sprawdza odstępy i połączenia każdej sieci i robi podglądy PNG
(`podglad_razem.png`: góra + ścieżki spodu na żółto).
Uruchomienie: w katalogu `src`: `python3 gen.py ../out2 && python3 check.py ../out2/model.json ../out2`.
