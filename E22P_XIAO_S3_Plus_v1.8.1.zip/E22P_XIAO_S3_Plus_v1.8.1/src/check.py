import json, sys, numpy as np
import geom as G
from scipy import ndimage as ndi
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

M = json.load(open(sys.argv[1]))
outdir = sys.argv[2]
for F in M["footprints"]:
    F["at"] = tuple(F["at"])
    for p in F["pads"]:
        p["doff"] = tuple(p["doff"])
cv = G.Canvas(M["BW"], M["BH"])
items = G.copper_items(M)
board = G.board_mask(cv, M)
nets = sorted(set(n for (_, n, _) in items))
errors = []

# --- DRC: odstępy między różnymi sieciami (miedź bez stref)
for L in ("F.Cu", "B.Cu"):
    masks = {n: G.render(cv, items, L, lambda x, n=n: x == n) for n in nets}
    masks = {n: m for n, m in masks.items() if m.any()}
    for n, m in masks.items():
        dist = ndi.distance_transform_edt(~m) * G.RES
        for n2, m2 in masks.items():
            if n2 <= n: continue
            need = max(G.clr_of(n), G.clr_of(n2)) - 0.03
            dd = dist[m2]
            if dd.size and dd.min() < need:
                idx = np.argwhere(m2 & (dist < need))[0]
                errors.append("%s: %s <-> %s odstęp %.3f mm @ (%.2f, %.2f)" % (
                    L, n, n2, dd.min(), idx[1] * G.RES, idx[0] * G.RES))
    # krawędź
    cu = np.zeros_like(board)
    for m in masks.values(): cu |= m
    de = ndi.distance_transform_edt(board) * G.RES
    bad = cu & (de < 0.3 - 0.03)
    if bad.any():
        idx = np.argwhere(bad)[0]
        errors.append("%s: miedź za blisko krawędzi @ (%.2f, %.2f)" % (L, idx[1] * G.RES, idx[0] * G.RES))
    # NPTH
    dn = ndi.distance_transform_edt(~G.npth_mask(cv, M)) * G.RES
    bad = cu & (dn < 0.25)
    if bad.any():
        errors.append("%s: miedź przy otworze montażowym" % L)

# otwory vs otwory
hm = G.holes_mask(cv, M)
# --- wypełnienie stref + połączenia
fills = G.fill_zones(cv, M, items, board)
layers_cu = {}
for L in ("F.Cu", "B.Cu"):
    layers_cu[L] = {}
    for n in nets:
        m = G.render(cv, items, L, lambda x, n=n: x == n)
        for (L2, n2), fm in fills.items():
            if L2 == L and n2 == n: m |= fm
        layers_cu[L][n] = m

# punkty przejścia między warstwami: przelotki + otwory THT
xfer = []
for (x, y, s, d, net) in M["vias"]:
    xfer.append((net, x, y))
for F in M["footprints"]:
    ax, ay = F["at"]
    for p in F["pads"]:
        if p["kind"] == "thru_hole" and p["net"]:
            xfer.append((p["net"], ax + p["x"], ay + p["y"]))

report = []
for n in nets:
    if n.startswith("__nc"): continue
    labs = {}
    offs = 0
    parent = {}
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    lab_imgs = {}
    for L in ("F.Cu", "B.Cu"):
        lab, k = ndi.label(layers_cu[L][n])
        lab_imgs[L] = (lab, offs)
        for i in range(1, k + 1): parent[offs + i] = offs + i
        offs += k
    for (net, x, y) in xfer:
        if net != n: continue
        i, j = int(round(y / G.RES)), int(round(x / G.RES))
        ids = []
        for L in ("F.Cu", "B.Cu"):
            lab, o = lab_imgs[L]
            if lab[i, j]: ids.append(o + lab[i, j])
        for a in ids[1:]:
            ra, rb = find(ids[0]), find(a)
            if ra != rb: parent[ra] = rb
    # komponenty zawierające pady
    padcomps = set()
    for F in M["footprints"]:
        ax, ay = F["at"]
        for p in F["pads"]:
            if p["net"] != n: continue
            i, j = int(round((ay + p["y"]) / G.RES)), int(round((ax + p["x"]) / G.RES))
            for L in ("F.Cu", "B.Cu"):
                if G.pad_on(p, L):
                    lab, o = lab_imgs[L]
                    if lab[i, j]: padcomps.add(find(o + lab[i, j]))
    report.append("%-16s grup z padami: %d" % (n, len(padcomps)))
    if len(padcomps) > 1:
        errors.append("NIEPOŁĄCZONA SIEĆ: %s (%d grup)" % (n, len(padcomps)))

print("\n".join(report))
print("\nBŁĘDY:" if errors else "\nDRC/połączenia: brak błędów")
for e in errors: print("  ", e)

# --- podgląd PNG
def show(L, fname, title):
    H, W = board.shape
    img = np.ones((H, W, 3)) * np.array([0.10, 0.10, 0.12])
    img[board] = np.array([0.15, 0.32, 0.18])
    cols = {"GND": (0.80, 0.62, 0.25), "+5V": (0.85, 0.25, 0.25), "+3V3": (0.95, 0.55, 0.20),
            "RF_ANT": (0.25, 0.75, 0.95)}
    for n, m in layers_cu[L].items():
        c = cols.get(n, (0.55, 0.85, 0.45))
        if n == "GND" and L == "B.Cu": c = (0.55, 0.62, 0.85)
        img[m] = c
    img[hm] = (0.05, 0.05, 0.05)
    flip = False
    if flip: img = img[:, ::-1]
    fig, ax = plt.subplots(figsize=(6.2, 10.5), dpi=130)
    ax.imshow(img, extent=(0, W * G.RES, H * G.RES, 0) if not flip else (W * G.RES, 0, H * G.RES, 0))
    if flip: ax.invert_xaxis()
    ax.set_title(title, fontsize=10)
    # obrysy elementów
    for F in M["footprints"]:
        ax_, ay_ = F["at"]
        for g in F["gfx"]:
            if g[0] in ("rect",) and g[1] in ("F.Fab",):
                (x0, y0), (x1, y1) = g[2], g[3]
                X = [ax_ + x0, ax_ + x1, ax_ + x1, ax_ + x0, ax_ + x0]
                Y = [ay_ + y0, ay_ + y0, ay_ + y1, ay_ + y1, ay_ + y0]
                ax.plot(X, Y, color="white", lw=0.6, ls="--" if L == "B.Cu" else "-", alpha=0.8)
            if g[0] == "circle" and g[1] == "F.SilkS" and g[3] > 2:
                c, r = g[2], g[3]
                t = np.linspace(0, 2 * np.pi, 80)
                ax.plot(ax_ + c[0] + r * np.cos(t), ay_ + c[1] + r * np.sin(t), color="white", lw=0.6, alpha=0.8)
        if L == "F.Cu":
            ax.text(ax_, ay_ - 0.0 if F["ref"] != "U1" else ay_ + 4, F["ref"], color="white", fontsize=6,
                    ha="center", va="center")
    ax.set_xlim(-1, M["BW"] + 1); ax.set_ylim(M["BH"] + 2, -1)
    ax.set_xlabel("mm")
    fig.tight_layout(); fig.savefig(fname); plt.close(fig)

show("F.Cu", outdir + "/podglad_top.png", "F.Cu (góra) – GND złoty, 5V czerwony, RF niebieski")
show("B.Cu", outdir + "/podglad_bottom.png", "B.Cu (spód, widok przez płytkę z góry) – tor RF GCPW pod E22P")

# --- widok łączony: góra + ścieżki spodu na żółto
H, W = board.shape
img = np.ones((H, W, 3)) * np.array([0.10, 0.10, 0.12])
img[board] = np.array([0.15, 0.32, 0.18])
cols = {"GND": (0.62, 0.50, 0.28), "+5V": (0.80, 0.25, 0.25), "+3V3": (0.95, 0.55, 0.20), "RF_ANT": (0.25, 0.70, 0.95)}
for n, m in layers_cu["F.Cu"].items():
    img[m] = cols.get(n, (0.45, 0.80, 0.40))
bot = G.render(cv, [it for it in items if it[2][0] != "pad"], "B.Cu", lambda n: n != "GND")
img[bot] = img[bot] * 0.15 + np.array([1.0, 0.88, 0.0]) * 0.85
img[hm] = (0.05, 0.05, 0.05)
fig, ax = plt.subplots(figsize=(9.0, 11.2), dpi=140)
ax.imshow(img, extent=(0, W * G.RES, H * G.RES, 0))
names = {"LORA_EN": "EN", "LORA_BUSY": "BUSY", "LORA_MOSI": "MOSI", "LORA_NSS": "NSS", "LORA_DIO1": "DIO1",
         "LORA_NRST": "NRST", "+3V3": "3V3", "RF_ANT": "ANT (spód)", "LORA_SCK": "SCK", "LORA_MISO": "MISO",
         "I2C_SCL": "SCL", "I2C_SDA": "SDA"}
lab = {"LORA_EN": (14, 47.0), "LORA_BUSY": (12.6, 53.2), "LORA_MOSI": (8.9, 61.6), "LORA_NSS": (30.0, 54.5),
       "LORA_DIO1": (32.3, 56.0), "LORA_NRST": (33.0, 66.5), "+3V3": (22.5, 72.4), "RF_ANT": (27.5, 11.0)}
for n, (x, y) in lab.items():
    ax.text(x, y, names[n], fontsize=5.5, color="black", ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.15", fc=(1, 0.9, 0.2), ec="none", alpha=0.9))
for F in M["footprints"]:
    ax_, ay_ = F["at"]
    for g in F["gfx"]:
        if g[0] == "rect" and g[1] == "F.Fab":
            (x0, y0), (x1, y1) = g[2], g[3]
            ax.plot([ax_ + x0, ax_ + x1, ax_ + x1, ax_ + x0, ax_ + x0], [ay_ + y0, ay_ + y0, ay_ + y1, ay_ + y1, ay_ + y0],
                    color="white", lw=0.6, alpha=0.8)
        if g[0] == "circle" and g[1] == "F.SilkS" and g[3] > 2:
            t = np.linspace(0, 2 * np.pi, 80)
            ax.plot(ax_ + g[2][0] + g[3] * np.cos(t), ay_ + g[2][1] + g[3] * np.sin(t), color="white", lw=0.6)
    ax.text(ax_, ay_ if F["ref"] != "U1" else ay_ + 4, F["ref"], color="white", fontsize=6, ha="center", va="center")
ax.set_xlim(-1, M["BW"] + 24); ax.set_ylim(M["BH"] + 2, -1)
ax.set_facecolor((0.35, 0.35, 0.38))
ax.text(M["BW"] + 11.5, 52.5, "gniazdo kątowe 1x4\n+ moduł SHT31\n(czujnikiem do góry,\npoza płytką)", fontsize=6, color="white", ha="center")
ax.set_title("Widok z góry: zielone = ścieżki F.Cu, ŻÓŁTE = ścieżki na spodzie (B.Cu)\n"
             "złoty = masa F.Cu, czerwony = 5V, niebieski = RF na górze", fontsize=8)
ax.set_xlabel("mm")
fig.tight_layout(); fig.savefig(outdir + "/podglad_razem.png"); plt.close(fig)
