#!/usr/bin/env python3
# Generator płytki E22P-868M30S + XIAO ESP32-S3 Plus (KiCad 8)
import math, uuid, json, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
NAME = "E22P_XIAO_S3_Plus"
os.makedirs(OUT, exist_ok=True)

def U(): return str(uuid.uuid4())
def f(v): return ("%.4f" % v).rstrip("0").rstrip(".") if abs(v) > 1e-9 else "0"

# ---------------------------------------------------------------- parametry
BW, BH = 40.0, 73.0          # wymiary płytki
CX = BW / 2                  # oś
NOTCH_W, NOTCH_D = 9.8, 1.6  # wcięcie pod kołnierz Amphenol 132289 (9.52 kw.)
EDGE_CLR = 0.3

RF_W, RF_GAP = 1.2, 0.2      # GCPW: ok. 50 Ω na FR4 1.6 mm, er 4.5
SIG_W, PWR_W = 0.25, 0.5

E22_TOP = 8.5                # górna krawędź modułu E22P
E22_L, E22_Wd = 38.5, 24.0
E22_C = (CX, E22_TOP + E22_L / 2)
GAP_E22_XIAO = 5.0
XIAO_L = 21.0
XIAO_TOP = E22_TOP + E22_L + GAP_E22_XIAO
XIAO_C = (CX, XIAO_TOP + XIAO_L / 2)
assert abs(XIAO_TOP + XIAO_L - BH) < 1e-6

# ---------------------------------------------------------------- sieci
NETS = ["", "GND", "+5V", "+3V3", "RF_ANT", "LORA_NRST", "LORA_DIO1", "LORA_NSS",
        "LORA_EN", "LORA_BUSY", "LORA_SCK", "LORA_MISO", "LORA_MOSI", "LORA_DIO2_TXRX",
        "I2C_SDA", "I2C_SCL", "XIAO_D6"]
NID = {n: i for i, n in enumerate(NETS)}

# ---------------------------------------------------------------- model
footprints = []   # dict(ref, value, lib, at, pads, gfx, attr, side)
tracks = []       # (layer, width, net, [pts])
vias = []         # (x, y, size, drill, net)
zones = []        # dict(net, layer, pts, priority, clearance, name)
edges = []        # ('line',a,b) / ('arc',a,m,b)
texts = []        # (text, x, y, layer, size, rot)

def pad(num, kind, shape, x, y, w, h, net="", drill=None, drill_off=(0, 0), layers=None, rr=0.25, zc=None):
    if layers is None:
        layers = ["F.Cu", "F.Paste", "F.Mask"] if kind == "smd" else ["*.Cu", "*.Mask"]
        if kind == "np_thru_hole": layers = ["*.Cu", "*.Mask"]
    return dict(num=num, kind=kind, shape=shape, x=x, y=y, w=w, h=h, net=net,
                drill=drill, doff=drill_off, layers=layers, rr=rr, zc=zc)

def fp(ref, value, lib, at, pads, gfx=(), attr="smd", reftxt=None):
    footprints.append(dict(ref=ref, value=value, lib=lib, at=at, pads=pads, gfx=list(gfx),
                           attr=attr, reftxt=reftxt))

def line(layer, a, b, w=0.12): return ("line", layer, a, b, w)
def rect(layer, a, b, w=0.12): return ("rect", layer, a, b, w)
def circ(layer, c, r, w=0.12): return ("circle", layer, c, r, w)
def ftext(layer, s, x, y, size=0.8): return ("text", layer, s, x, y, size)

def trk(layer, net, pts, w=SIG_W): tracks.append((layer, w, net, pts))
def via(x, y, net, size=0.6, drill=0.3): vias.append((x, y, size, drill, net))

# ================================================================ J1: SMA krawędziowe
# Środek złącza na osi, korpus wchodzi 1 mm we wcięcie. Pola GND szerokie po obu stronach,
# na obu warstwach. Uniwersalne pod RF2-143-T-17-50-G i Amphenol 132289 (płytka 1.6 mm).
sma_pads = []
cp_y0, cp_y1 = NOTCH_D + EDGE_CLR, 7.6          # pad środkowy
g_in, g_out = RF_W / 2 + RF_GAP, 8.5             # pola GND: od 0.8 do 8.5 mm od osi (nogi 132289: 4.25 +-0.51)
g_y1 = 7.6
sh_x0 = NOTCH_W / 2 + EDGE_CLR                   # ramiona obok wcięcia
lx = lambda x: x                                  # lokalnie: x względem osi, y od krawędzi
sma_pads.append(pad("1", "smd", "rect", 0, (cp_y0 + cp_y1) / 2, RF_W, cp_y1 - cp_y0, "RF_ANT",
                    layers=["F.Cu", "F.Mask"]))
for side in (-1, 1):
    for L, lay in (("F", ["F.Cu", "F.Mask"]), ("B", ["B.Cu", "B.Mask"])):
        # pole pod nogę (od dna wcięcia w dół)
        x0, x1 = side * g_in, side * g_out
        sma_pads.append(pad("2", "smd", "rect", (x0 + x1) / 2, (cp_y0 + g_y1) / 2,
                            abs(x1 - x0), g_y1 - cp_y0, "GND", layers=lay))
        # ramię obok wcięcia (do lutowania boku korpusu)
        x0, x1 = side * sh_x0, side * g_out
        sma_pads.append(pad("2", "smd", "rect", (x0 + x1) / 2, (EDGE_CLR + cp_y0) / 2,
                            abs(x1 - x0), cp_y0 - EDGE_CLR, "GND", layers=lay))
# B.Cu pod pinem środkowym – GND (odniesienie dla wejścia złącza)
sma_pads.append(pad("2", "smd", "rect", 0, (cp_y0 + 6.2) / 2, 2 * g_in, 6.2 - cp_y0, "GND",
                    layers=["B.Cu", "B.Mask"]))
sma_gfx = [
    rect("F.Fab", (-NOTCH_W / 2, -9.0), (NOTCH_W / 2, NOTCH_D), 0.1),
    line("F.SilkS", (-g_out - 0.3, g_y1 + 0.3), (g_out + 0.3, g_y1 + 0.3)),
    ftext("F.SilkS", "ANT", -11.0, 5.5, 0.8),
    rect("F.CrtYd", (-g_out - 0.3, -9.5), (g_out + 0.3, g_y1 + 0.5), 0.05),
]
fp("J1", "SMA_Amphenol_132289", "custom:SMA_Edge_1.6mm_wide_GND",
   (CX, 0.0), sma_pads, sma_gfx, "smd", reftxt=(0, 4.0, "F.Fab"))
SMA_VIA = (CX, 7.0)

# ================================================================ U1: E22P-868M30S
# Footprint jak E22-900M30S: 2x11 padów (półotwory) raster 2.54, rzędy 24.0 mm,
# pady 1-3 / 20-22 przy końcu antenowym, przerwa 7.6 mm między 3-4 i 19-20.
off_from_top = [4.02, 6.56, 9.10, 16.70, 19.24, 21.78, 24.32, 26.86, 29.40, 31.94, 34.48]
e22_names = {1: "GND", 2: "GND", 3: "GND", 4: "GND", 5: "GND", 6: "LORA_EN", 7: "LORA_DIO2_TXRX",
             8: "LORA_DIO2_TXRX", 9: "+5V", 10: "+5V", 11: "GND", 12: "GND", 13: "LORA_DIO1",
             14: "LORA_BUSY", 15: "LORA_NRST", 16: "LORA_MISO", 17: "LORA_MOSI", 18: "LORA_SCK",
             19: "LORA_NSS", 20: "GND", 21: "RF_ANT", 22: "GND"}
PAD_L, PAD_W, PAD_OUT = 3.75, 1.5, 0.625  # pad 3.75 x 1.5: 1.25 pod modułem, 2.5 na zewnątrz
e22_pads, E22PAD = [], {}
for i, o in enumerate(off_from_top):
    yl = -E22_L / 2 + o
    for num, sx in ((i + 1, -1), (22 - i, 1)):
        x = sx * (E22_Wd / 2 + PAD_OUT)
        e22_pads.append(pad(str(num), "smd", "rect", x, yl, PAD_L, PAD_W, e22_names[num]))
        E22PAD[num] = (E22_C[0] + x, E22_C[1] + yl)
hw, hl = E22_Wd / 2, E22_L / 2
e22_gfx = [
    rect("F.Fab", (-hw, -hl), (hw, hl), 0.1),
    line("F.SilkS", (-hw, -hl), (hw, -hl)), line("F.SilkS", (-hw, hl), (hw, hl)),
    line("F.SilkS", (-hw, -hl + 1.5), (-hw, -hl)), line("F.SilkS", (hw, -hl + 1.5), (hw, -hl)),
    line("F.SilkS", (-hw, hl - 1.6), (-hw, hl)), line("F.SilkS", (hw, hl - 1.6), (hw, hl)),
    circ("F.SilkS", (-hw - 3.2, -hl + off_from_top[0]), 0.3, 0.3),
    ftext("F.SilkS", "E22P-868M30S", 0, -2.0, 1.2),
    ftext("F.SilkS", "GND (ekran)", 0, 0.2, 0.9),
    ftext("F.SilkS", "ANT", hw - 3.6, -hl + off_from_top[1], 0.8),
    rect("F.CrtYd", (-hw - 2.8, -hl - 0.3), (hw + 2.8, hl + 0.3), 0.05),
]
fp("U1", "E22P-868M30S", "custom:EBYTE_E22P-xxxM30S", E22_C, e22_pads, e22_gfx, "smd",
   reftxt=(0, 2.2))

# ================================================================ U2: XIAO ESP32-S3 Plus (goldpiny)
# USB-C w dół (wystaje poza krawędź). Otwory 1.0 mm, rzędy 15.24 mm, raster 2.54.
xr = 7.62
col_y = [-7.62, -5.08, -2.54, 0, 2.54, 5.08, 7.62]
left = [(8, "LORA_BUSY", "D7"), (9, "LORA_SCK", "D8"), (10, "LORA_MISO", "D9"), (11, "LORA_MOSI", "D10"),
        (12, "+3V3", "3V3"), (13, "GND", "GND"), (14, "+5V", "5V")]
right = [(7, "XIAO_D6", "D6"), (6, "I2C_SCL", "D5"), (5, "I2C_SDA", "D4"), (4, "LORA_EN", "D3"),
         (3, "LORA_NSS", "D2"), (2, "LORA_DIO1", "D1"), (1, "LORA_NRST", "D0")]
XP_W, XP_H, XP_OFF, XP_DRILL = 2.2, 1.5, 0.35, 1.0
xiao_pads, XPAD = [], {}
xiao_gfx = []
for (lst, sx) in ((left, -1), (right, 1)):
    for (num, net, lab), yy in zip(lst, col_y):
        px = sx * xr                       # (at) = środek otworu
        xiao_pads.append(pad(str(num), "thru_hole", "rect" if num == 1 else "oval", px, yy, XP_W, XP_H,
                             net, drill=XP_DRILL,
                             drill_off=(sx * XP_OFF, 0),   # kształt pada przesunięty na zewnątrz
                             zc=2 if net in ("GND", "+5V") else None))
        XPAD[lab] = (XIAO_C[0] + sx * xr, XIAO_C[1] + yy)
        if sx > 0:
            xiao_gfx.append(ftext("F.SilkS", lab, sx * (xr + 2.75), yy, 0.8))
        else:
            xiao_gfx.append(ftext("B.SilkS", lab, sx * (xr + 2.75), yy, 0.8))
bw2, bl2 = 17.8 / 2, XIAO_L / 2
xiao_gfx += [
    rect("F.Fab", (-bw2, -bl2), (bw2, bl2), 0.1),
    line("F.SilkS", (-bw2, -bl2 - 0.2), (bw2, -bl2 - 0.2)),
    ftext("F.SilkS", "XIAO ESP32-S3 Plus", 0, -bl2 - 1.0, 0.9),
    rect("F.Fab", (-4.5, bl2 - 6.0), (4.5, bl2 + 1.5), 0.1),
    rect("F.CrtYd", (-bw2 - 0.3, -bl2 - 0.3), (bw2 + 0.3, bl2 + 1.8), 0.05),
]
fp("U2", "XIAO_ESP32S3_Plus", "custom:XIAO_ESP32S3_Plus_THT_heatsink_cutout", XIAO_C, xiao_pads,
   xiao_gfx, "through_hole", reftxt=(0, 0, "F.Fab"))

# wycięcie pod radiator (w Edge.Cuts)
CUT_W, CUT_Y0, CUT_Y1, CUT_R = 12.9, XIAO_TOP + 2.0, XIAO_TOP + 18.0, 1.0

# ================================================================ kondensatory / R / złącze czujnika
C_X = 2.6
C2P, C2N = (C_X, 31.0), (C_X, 31.0 + 5.08)
C1P, C1N = (C_X, 38.6), (C_X, 38.6 + 2.54)
C3C = (5.45, 52.7)
C3P, C3N = (C3C[0], C3C[1] - 2.5), (C3C[0], C3C[1] + 2.5)

def radial(ref, val, lib, p_plus, p_minus, body, pol, dia=1.6, drill=0.9, rect_body=None, dia_minus=None):
    cxl, cyl = p_plus
    pads_ = [pad("1", "thru_hole", "rect" if pol else "circle", 0, 0, dia, dia, "+5V", drill=drill),
             pad("2", "thru_hole", "circle", p_minus[0] - cxl, p_minus[1] - cyl, dia_minus or dia,
                 dia_minus or dia, "GND", drill=drill)]
    g = []
    my = (p_minus[1] - cyl) / 2
    if rect_body:
        w, h = rect_body
        g.append(line("F.SilkS", (-w / 2, my - h / 2), (-w / 2, my + h / 2)))
        g.append(line("F.SilkS", (w / 2, my - h / 2), (w / 2, my + h / 2)))
        g.append(rect("F.CrtYd", (-w / 2 - 0.2, my - h / 2 - 0.2), (w / 2 + 0.2, my + h / 2 + 0.2), 0.05))
    else:
        g.append(circ("F.SilkS", (0, my), body))
        g.append(circ("F.CrtYd", (0, my), body + 0.25, 0.05))
    if pol:
        g.append(ftext("F.SilkS", "+", -1.6 if rect_body else -1.9, -0.2, 1.0))
    fp(ref, val, lib, p_plus, pads_, g, "through_hole",
       reftxt=(2.6, my, "F.SilkS") if pol else (0, my, "F.Fab"))

radial("C2", "10uF MLCC THT", "custom:C_Disc_P5.08mm", C2P, C2N, 0, False, rect_body=(3.4, 6.6), dia_minus=2.4)
radial("C1", "100nF THT", "custom:C_Disc_P2.54mm", C1P, C1N, 0, False, rect_body=(3.0, 4.4), dia_minus=2.4)
radial("C3", "470uF 16V polimer", "custom:CP_Radial_D10mm_P5.00mm", C3P, C3N, 5.0, True,
       dia=2.0, drill=1.0, dia_minus=3.0)

# R1 10k THT (osiowy 1/4 W, raster 7.62) przy pinie 6 (EN), leżący w lewym pasie
R1E, R1G = (2.6, 28.62), (2.6, 28.62 - 7.62)
fp("R1", "10k THT", "custom:R_Axial_P7.62mm", R1E,
   [pad("1", "thru_hole", "circle", 0, 0, 1.6, 1.6, "LORA_EN", drill=0.8),
    pad("2", "thru_hole", "circle", 0, R1G[1] - R1E[1], 1.6, 1.6, "GND", drill=0.8)],
   [rect("F.SilkS", (-1.3, -6.55), (1.3, -1.07)), ftext("F.SilkS", "10k", 0, -3.81, 0.8),
    rect("F.CrtYd", (-1.5, -8.6), (1.5, 1.0), 0.05)], "through_hole", reftxt=(0, -3.81, "F.Fab"))

J2X = 37.6
# J2: gniazdo żeńskie kątowe 1x4 2.54 (otwór wychodzi za prawą krawędź) pod moduł SHT31.
# Kolejność jak na module: VIN, GND, SCL, SDA. Moduł leży poziomo, czujnikiem do góry, poza płytką.
Y5, Y4, Y3, Y2 = XPAD["D5"][1], XPAD["D4"][1], XPAD["D3"][1], XPAD["D2"][1]
j2 = [("1", "+3V3", "VIN", Y5), ("2", "GND", "GND", Y4), ("3", "I2C_SCL", "SCL", Y3), ("4", "I2C_SDA", "SDA", Y2)]
j2y0 = j2[0][3]
fp("J2", "SHT31 (gniazdo katowe 1x4)", "custom:PinSocket_1x04_P2.54mm_Horizontal", (J2X, j2y0),
   [pad(n, "thru_hole", "rect" if n == "1" else "oval", 0, y - j2y0, 1.7, 1.7, net, drill=1.0)
    for n, net, lab, y in j2],
   [rect("F.Fab", (1.3, -1.27), (1.3 + 8.5, 3 * 2.54 + 1.27), 0.1),
    rect("F.Fab", (9.8, -2.0), (9.8 + 13.0, 3 * 2.54 + 2.0), 0.1),
    rect("F.CrtYd", (-1.5, -1.5), (2.4, 3 * 2.54 + 1.5), 0.05)],
   "through_hole", reftxt=(0, -2.3, "F.Fab"))

# J3 – zasilanie 5 V przewodem (np. 0,5 mm2) zamiast USB: dwa otwory 1.3 mm
J3P = (4.5, 59.6)
fp("J3", "5V_IN", "custom:Wire_Pads_2x_D1.3mm_P3.5mm", J3P,
   [pad("1", "thru_hole", "rect", 0, 0, 2.6, 2.6, "+5V", drill=1.3, zc=2),
    pad("2", "thru_hole", "circle", 0, 3.5, 2.6, 2.6, "GND", drill=1.3, zc=2)],
   [ftext("F.SilkS", "+5V", 3.1, 0, 0.8), ftext("F.SilkS", "GND", 3.1, 3.5, 0.8),
    rect("F.CrtYd", (-1.6, -1.6), (1.6, 5.1), 0.05)], "through_hole", reftxt=(-2.9, 1.75))

# J4 – wyprowadzenie D6 / GPIO43 na przewód do 0,35 mm2 (otwór 1.0 mm)
J4P = (34.0, XPAD["D6"][1])
fp("J4", "GPIO43", "custom:Wire_Pad_D1.0mm", J4P,
   [pad("1", "thru_hole", "circle", 0, 0, 2.2, 2.2, "XIAO_D6", drill=1.0)],
   [ftext("F.SilkS", "IO43", 3.0, 0, 0.8), rect("F.CrtYd", (-1.3, -1.3), (1.3, 1.3), 0.05)],
   "through_hole", reftxt=(0, -1.9))

# otwory montażowe M3 (NPTH 3.2)
HOLES = [(3.5, 3.5), (BW - 3.5, 3.5), (3.5, 69.5), (BW - 2.8, 70.0)]
for i, (hx, hy) in enumerate(HOLES):
    fp("H%d" % (i + 1), "M3", "custom:MountingHole_3.2mm", (hx, hy),
       [pad("", "np_thru_hole", "circle", 0, 0, 3.2, 3.2, "", drill=3.2)],
       [circ("F.CrtYd", (0, 0), 2.1, 0.05), circ("Cmts.User", (0, 0), 1.6, 0.1)], "through_hole",
       reftxt=(0, 0, "F.Fab"))

# ================================================================ ścieżki
# --- RF: pin 21 -> przelotka -> B.Cu pod E22P -> przelotka -> pad środkowy SMA
p21 = E22PAD[21]
RFV1 = (E22_C[0] + E22_Wd / 2 + 0.9, p21[1])
RF_BEND = (CX, 10.0)
via(*RFV1, "RF_ANT", size=0.8, drill=0.4)
via(*SMA_VIA, "RF_ANT", size=0.8, drill=0.4)
trk("B.Cu", "RF_ANT", [RFV1, RF_BEND, SMA_VIA], RF_W)

# --- mostek DIO2 <-> T/R CTRL (piny 8 i 7)
xb = E22PAD[7][0] - 1.0
trk("F.Cu", "LORA_DIO2_TXRX", [(xb, E22PAD[7][1]), (xb, E22PAD[8][1])], 0.5)

# --- EN: pin 6 -> via -> B.Cu wzdłuż dolnej krawędzi modułu -> D3 (od spodu)
p6 = E22PAD[6]
ENV = (4.4, p6[1])
trk("F.Cu", "LORA_EN", [(p6[0] - 1.5, p6[1]), ENV])
via(*ENV, "LORA_EN")
EN_Y, EN_X = 47.5, 29.8
d3 = XPAD["D3"]
trk("B.Cu", "LORA_EN", [ENV, (ENV[0], EN_Y), (EN_X, EN_Y), (EN_X, d3[1]), (d3[0], d3[1])])
# R1 pull-down przy pinie 6 (F.Cu)
trk("F.Cu", "LORA_EN", [R1E, (R1E[0] + 1.0, R1E[1]), ENV])

# --- sygnały z prawej strony E22P: tory pionowe w prawym pasie (F.Cu)
lanes = {13: 35.3, 14: 35.9, 15: 36.5, 16: 37.1, 17: 37.7, 18: 38.3, 19: 38.9}
rows = {13: 48.0, 14: 48.65, 15: 49.3, 16: 49.95, 17: 50.6, 18: 51.25, 19: 51.9}
def right_start(n):
    x, y = E22PAD[n]
    return [(x + 1.5, y), (lanes[n], y), (lanes[n], rows[n])]

# DIO1 / NRST / NSS -> przelotka -> B.Cu -> prawa kolumna XIAO (D1 / D0 / D2)
for n, vx, lab in ((13, 31.3, "D1"), (15, 32.0, "D0"), (19, 30.6, "D2")):
    net = e22_names[n]
    pts = right_start(n) + [(vx, rows[n])]
    trk("F.Cu", net, pts)
    via(vx, rows[n], net)
    tx, ty = XPAD[lab]
    trk("B.Cu", net, [(vx, rows[n]), (vx, ty), (tx, ty)])

# BUSY -> F.Cu do (12.03,row) -> via -> B.Cu w dół do D7
d7 = XPAD["D7"]
pts = right_start(14) + [(d7[0], rows[14])]
trk("F.Cu", "LORA_BUSY", pts); via(d7[0], rows[14], "LORA_BUSY")
trk("B.Cu", "LORA_BUSY", [(d7[0], rows[14]), d7])
# MOSI -> F.Cu do (10.55,row) -> via -> B.Cu po zewnętrznej stronie do D10
d10 = XPAD["D10"]
MV = (10.55, rows[17])
trk("F.Cu", "LORA_MOSI", right_start(17) + [MV]); via(*MV, "LORA_MOSI")
trk("B.Cu", "LORA_MOSI", [MV, (10.0, MV[1] + 0.55), (10.0, d10[1]), d10])
# SCK -> F.Cu tor 10.45 -> D8 ; MISO -> F.Cu tor 9.85 -> D9
d8, d9 = XPAD["D8"], XPAD["D9"]
trk("F.Cu", "LORA_SCK", right_start(18) + [(10.45, rows[18]), (10.45, d8[1]), d8])
trk("F.Cu", "LORA_MISO", right_start(16) + [(9.85, rows[16]), (9.85, d9[1]), d9])

# --- D6 (GPIO43) -> J4 (F.Cu)
trk("F.Cu", "XIAO_D6", [XPAD["D6"], J4P], 0.4)
# --- I2C do J2 (F.Cu): SCL D5 -> J2.3, SDA D4 -> J2.4
x5, _ = XPAD["D5"]; x4, _ = XPAD["D4"]
trk("F.Cu", "I2C_SCL", [(x5, Y5), (34.6, Y5), (34.6, Y3), (J2X, Y3)])
trk("F.Cu", "I2C_SDA", [(x4, Y4), (33.0, Y4), (33.0, Y2), (J2X, Y2)])
# --- 3V3: XIAO 3V3 -> B.Cu pod mostkiem pod wycięciem -> J2.1 (VIN)
v3 = XPAD["3V3"]
Y33 = 71.8
trk("B.Cu", "+3V3", [v3, (10.0, v3[1]), (10.0, Y33), (34.6, Y33), (34.6, Y5), (J2X, Y5)], PWR_W)

# ================================================================ strefy
board_poly = [(0, 0), (CX - NOTCH_W / 2, 0), (CX - NOTCH_W / 2, NOTCH_D), (CX + NOTCH_W / 2, NOTCH_D),
              (CX + NOTCH_W / 2, 0), (BW, 0), (BW, BH), (0, BH)]
zones.append(dict(net="GND", layer="F.Cu", pts=board_poly, priority=0, name="GND_TOP"))
zones.append(dict(net="GND", layer="B.Cu", pts=board_poly, priority=0, name="GND_BOT"))
p5 = XPAD["5V"]
v5_poly = [(0.3, 29.6), (5.2, 29.6), (5.2, 36.4), (9.25, 36.4), (9.25, 41.6), (5.2, 41.6),
           (5.2, 47.0), (9.3, 47.0), (9.3, p5[1] - 0.9), (p5[0] + 0.3, p5[1] - 0.9),
           (p5[0] + 0.3, p5[1] + 0.9), (9.3, p5[1] + 0.9), (9.3, BH - 0.3), (0.3, BH - 0.3)]
zones.append(dict(net="+5V", layer="F.Cu", pts=v5_poly, priority=1, name="5V_TOP"))

# ================================================================ krawędzie
for a, b in zip(board_poly, board_poly[1:] + board_poly[:1]):
    edges.append(("line", a, b))
x0, x1 = CX - CUT_W / 2, CX + CUT_W / 2
r = CUT_R
s2 = math.sqrt(0.5)
edges += [("line", (x0 + r, CUT_Y0), (x1 - r, CUT_Y0)), ("line", (x1, CUT_Y0 + r), (x1, CUT_Y1 - r)),
          ("line", (x1 - r, CUT_Y1), (x0 + r, CUT_Y1)), ("line", (x0, CUT_Y1 - r), (x0, CUT_Y0 + r)),
          ("arc", (x1 - r, CUT_Y0), (x1 - r + r * s2, CUT_Y0 + r - r * s2), (x1, CUT_Y0 + r)),
          ("arc", (x1, CUT_Y1 - r), (x1 - r + r * s2, CUT_Y1 - r + r * s2), (x1 - r, CUT_Y1)),
          ("arc", (x0 + r, CUT_Y1), (x0 + r - r * s2, CUT_Y1 - r + r * s2), (x0, CUT_Y1 - r)),
          ("arc", (x0, CUT_Y0 + r), (x0 + r - r * s2, CUT_Y0 + r - r * s2), (x0 + r, CUT_Y0))]

# ================================================================ teksty
texts += [
    ("radiator", CX, (CUT_Y0 + CUT_Y1) / 2 - 1.0, "F.SilkS", 1.0, 0),
    ("12.9x16", CX, (CUT_Y0 + CUT_Y1) / 2 + 0.8, "F.SilkS", 0.8, 0),
    ("USB-C", CX, BH - 1.2, "F.SilkS", 0.9, 0),
    ("VIN", J2X - 2.4, Y5, "F.SilkS", 0.8, 0),
    ("GND", J2X - 2.4, Y4, "F.SilkS", 0.8, 0),
    ("SCL", J2X - 2.4, Y3, "F.SilkS", 0.8, 0),
    ("SDA", J2X - 2.4, Y2, "F.SilkS", 0.8, 0),
    ("SHT31 ->", 35.0, Y2 + 2.2, "F.SilkS", 0.8, 0),
    ("5V", 2.2, 45.0, "F.SilkS", 0.8, 0),
    ("E22P+XIAO S3+ v1.0 rpc", CX, 8.9, "B.SilkS", 0.9, 0),
    ("RF GCPW 1.2/0.2 ~50R", 27.0, 17.6, "B.SilkS", 0.8, 0),
    ("Meshtastic 868", CX, 40.0, "B.SilkS", 1.2, 0),
]

# ================================================================ eksport do KiCad
def stroke(w): return "(stroke (width %s) (type solid))" % f(w)
def effects(size, mirror=False, hide=False):
    s = "(effects (font (size %s %s) (thickness %s))%s)" % (f(size), f(size), f(max(0.1, size * 0.15)),
                                                          " (justify mirror)" if mirror else "")
    return s

def gfx_sexp(g):
    k = g[0]
    if k == "line":
        _, lay, a, b, w = g
        return '(fp_line (start %s %s) (end %s %s) %s (layer "%s") (uuid "%s"))' % (
            f(a[0]), f(a[1]), f(b[0]), f(b[1]), stroke(w), lay, U())
    if k == "rect":
        _, lay, a, b, w = g
        return '(fp_rect (start %s %s) (end %s %s) %s (fill none) (layer "%s") (uuid "%s"))' % (
            f(a[0]), f(a[1]), f(b[0]), f(b[1]), stroke(w), lay, U())
    if k == "circle":
        _, lay, c, r, w = g
        return '(fp_circle (center %s %s) (end %s %s) %s (fill none) (layer "%s") (uuid "%s"))' % (
            f(c[0]), f(c[1]), f(c[0] + r), f(c[1]), stroke(w), lay, U())
    if k == "text":
        _, lay, s, x, y, size = g
        if size <= 0: return ""
        return '(fp_text user "%s" (at %s %s 0) (layer "%s") (uuid "%s") %s)' % (
            s, f(x), f(y), lay, U(), effects(size, mirror=lay.startswith("B.")))
    raise ValueError(k)

def pad_sexp(p):
    net = ""
    if p["net"]:
        net = '(net %d "%s")' % (NID[p["net"]], p["net"])
    drill = ""
    if p["drill"]:
        if p["doff"] != (0, 0):
            drill = "(drill %s (offset %s %s))" % (f(p["drill"]), f(p["doff"][0]), f(p["doff"][1]))
        else:
            drill = "(drill %s)" % f(p["drill"])
    rr = "(roundrect_rratio %s)" % f(p["rr"]) if p["shape"] == "roundrect" else ""
    lays = " ".join('"%s"' % l for l in p["layers"])
    zc = "(zone_connect %d)" % p["zc"] if p.get("zc") is not None else ""
    return '(pad "%s" %s %s (at %s %s) (size %s %s) %s (layers %s) %s %s %s (uuid "%s"))' % (
        p["num"], p["kind"], p["shape"], f(p["x"]), f(p["y"]), f(p["w"]), f(p["h"]), drill, lays, rr, net, zc, U())

out = []
out.append('(kicad_pcb (version 20240108) (generator "pcbnew") (generator_version "8.0")')
out.append('(general (thickness 1.6) (legacy_teardrops no))')
out.append('(paper "A4")')
out.append('''(layers
 (0 "F.Cu" signal) (31 "B.Cu" signal) (32 "B.Adhes" user "B.Adhesive") (33 "F.Adhes" user "F.Adhesive")
 (34 "B.Paste" user) (35 "F.Paste" user) (36 "B.SilkS" user "B.Silkscreen") (37 "F.SilkS" user "F.Silkscreen")
 (38 "B.Mask" user) (39 "F.Mask" user) (40 "Dwgs.User" user "User.Drawings") (41 "Cmts.User" user "User.Comments")
 (42 "Eco1.User" user "User.Eco1") (43 "Eco2.User" user "User.Eco2") (44 "Edge.Cuts" user) (45 "Margin" user)
 (46 "B.CrtYd" user "B.Courtyard") (47 "F.CrtYd" user "F.Courtyard") (48 "B.Fab" user) (49 "F.Fab" user))''')
out.append('''(setup
 (stackup
  (layer "F.SilkS" (type "Top Silk Screen")) (layer "F.Paste" (type "Top Solder Paste"))
  (layer "F.Mask" (type "Top Solder Mask") (thickness 0.01))
  (layer "F.Cu" (type "copper") (thickness 0.035))
  (layer "dielectric 1" (type "core") (thickness 1.51) (material "FR4") (epsilon_r 4.5) (loss_tangent 0.02))
  (layer "B.Cu" (type "copper") (thickness 0.035))
  (layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01)) (layer "B.Paste" (type "Bottom Solder Paste"))
  (layer "B.SilkS" (type "Bottom Silk Screen"))
  (copper_finish "HAL lead-free") (dielectric_constraints no))
 (pad_to_mask_clearance 0) (allow_soldermask_bridges_in_footprints no)
 (pcbplotparams (layerselection 0x00010fc_ffffffff) (plot_on_all_layers_selection 0x0000000_00000000)
  (disableapertmacros no) (usegerberextensions no) (usegerberattributes yes) (usegerberadvancedattributes yes)
  (creategerberjobfile yes) (dashed_line_dash_ratio 12.000000) (dashed_line_gap_ratio 3.000000)
  (svgprecision 4) (plotframeref no) (viasonmask no) (mode 1) (useauxorigin no) (hpglpennumber 1)
  (hpglpenspeed 20) (hpglpendiameter 15.000000) (pdf_front_fp_property_popups yes)
  (pdf_back_fp_property_popups yes) (dxfpolygonmode yes) (dxfimperialunits yes) (dxfusepcbnewfont yes)
  (psnegative no) (psa4output no) (plotreference yes) (plotvalue no) (plotfptext yes) (plotinvisibletext no)
  (sketchpadsonfab no) (subtractmaskfromsilk yes) (outputformat 1) (mirror no) (drillshape 0)
  (scaleselection 1) (outputdirectory "gerber/")))''')
for i, n in enumerate(NETS):
    out.append('(net %d "%s")' % (i, n))

for F in footprints:
    x, y = F["at"]
    rt = F["reftxt"] if F["reftxt"] else (0, -2.0)
    rx, ry = rt[0], rt[1]
    rlay = rt[2] if len(rt) > 2 else "F.SilkS"
    s = ['(footprint "%s" (layer "F.Cu") (uuid "%s") (at %s %s)' % (F["lib"], U(), f(x), f(y))]
    s.append('(property "Reference" "%s" (at %s %s 0) (layer "%s") (uuid "%s") %s)' % (
        F["ref"], f(rx), f(ry), rlay, U(), effects(0.9)))
    s.append('(property "Value" "%s" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "%s") %s)' % (
        F["value"], U(), effects(0.8)))
    s.append('(property "Footprint" "%s" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "%s") %s)' % (
        F["lib"], U(), effects(0.8)))
    s.append('(property "Datasheet" "" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "%s") %s)' % (U(), effects(0.8)))
    s.append('(property "Description" "" (at 0 0 0) (layer "F.Fab") (hide yes) (uuid "%s") %s)' % (U(), effects(0.8)))
    attr = F["attr"]
    s.append("(attr %s%s)" % (attr, " board_only" if F["ref"].startswith("H") else ""))
    for g in F["gfx"]:
        t = gfx_sexp(g)
        if t: s.append(t)
    for p in F["pads"]:
        s.append(pad_sexp(p))
    s.append(")")
    out.append("\n ".join(s))

for (lay, w, net, pts) in tracks:
    for a, b in zip(pts, pts[1:]):
        if abs(a[0] - b[0]) < 1e-9 and abs(a[1] - b[1]) < 1e-9: continue
        out.append('(segment (start %s %s) (end %s %s) (width %s) (layer "%s") (net %d) (uuid "%s"))' % (
            f(a[0]), f(a[1]), f(b[0]), f(b[1]), f(w), lay, NID[net], U()))

def emit_vias():
    for (x, y, s, d, net) in vias:
        out.append('(via (at %s %s) (size %s) (drill %s) (layers "F.Cu" "B.Cu") (net %d) (uuid "%s"))' % (
            f(x), f(y), f(s), f(d), NID[net], U()))

for e in edges:
    if e[0] == "line":
        out.append('(gr_line (start %s %s) (end %s %s) (stroke (width 0.1) (type default)) (layer "Edge.Cuts") (uuid "%s"))' % (
            f(e[1][0]), f(e[1][1]), f(e[2][0]), f(e[2][1]), U()))
    else:
        out.append('(gr_arc (start %s %s) (mid %s %s) (end %s %s) (stroke (width 0.1) (type default)) (layer "Edge.Cuts") (uuid "%s"))' % (
            f(e[1][0]), f(e[1][1]), f(e[2][0]), f(e[2][1]), f(e[3][0]), f(e[3][1]), U()))
for (t, x, y, lay, size, rot) in texts:
    out.append('(gr_text "%s" (at %s %s %s) (layer "%s") (uuid "%s") %s)' % (
        t, f(x), f(y), f(rot), lay, U(), effects(size, mirror=lay.startswith("B."))))

def emit_zones():
    for z in zones:
        pts = " ".join("(xy %s %s)" % (f(a), f(b)) for a, b in z["pts"])
        out.append('''(zone (net %d) (net_name "%s") (layer "%s") (uuid "%s") (name "%s") (hatch edge 0.5) (priority %d)
 (connect_pads thru_hole_only (clearance 0.2)) (min_thickness 0.25) (filled_areas_thickness no)
 (fill (thermal_gap 0.4) (thermal_bridge_width 0.5) (island_removal_mode 0))
 (polygon (pts %s)))''' % (NID[z["net"]], z["net"], z["layer"], U(), z["name"], z["priority"], pts))

# zapis modelu do JSON (dla DRC/podglądu) – przelotki zszywające dodaje stitch.py
model = dict(BW=BW, BH=BH, footprints=footprints, tracks=tracks, vias=vias, zones=zones,
             edges=edges, holes=HOLES, cut=(x0, CUT_Y0, x1, CUT_Y1, CUT_R), notch=(NOTCH_W, NOTCH_D),
             rf=dict(path=[RFV1, RF_BEND, SMA_VIA]), v5_poly=v5_poly)

if __name__ == "__main__":
    import stitch
    extra = stitch.make_stitching(model)
    for (x, y) in extra:
        via(x, y, "GND")
    emit_vias()
    emit_zones()
    out.append(")")
    with open(os.path.join(OUT, NAME + ".kicad_pcb"), "w") as fh:
        fh.write("\n".join(out) + "\n")
    pro = {
        "board": {"design_settings": {
            "rule_severities": {"lib_footprint_issues": "ignore", "lib_footprint_mismatch": "ignore"},
            "defaults": {"board_outline_line_width": 0.1, "copper_line_width": 0.2},
            "rules": {"min_clearance": 0.2, "min_copper_edge_clearance": 0.3, "min_track_width": 0.2,
                      "min_via_diameter": 0.6, "min_through_hole_diameter": 0.3, "min_hole_clearance": 0.25,
                      "min_hole_to_hole": 0.25, "min_via_annular_width": 0.13},
            "track_widths": [0.0, 0.25, 0.5, 0.8, 1.2], "via_dimensions": [{"diameter": 0.0, "drill": 0.0},
                                                                         {"diameter": 0.6, "drill": 0.3},
                                                                         {"diameter": 0.8, "drill": 0.4}]}},
        "meta": {"filename": NAME + ".kicad_pro", "version": 1},
        "net_settings": {"classes": [
            {"name": "Default", "clearance": 0.2, "track_width": 0.25, "via_diameter": 0.6, "via_drill": 0.3,
             "microvia_diameter": 0.3, "microvia_drill": 0.1, "diff_pair_gap": 0.25, "diff_pair_width": 0.2,
             "diff_pair_via_gap": 0.25, "wire_width": 6, "bus_width": 12, "line_style": 0,
             "pcb_color": "rgba(0, 0, 0, 0.000)", "schematic_color": "rgba(0, 0, 0, 0.000)", "priority": 2147483647},
            {"name": "RF", "clearance": 0.2, "track_width": 1.2, "via_diameter": 0.8, "via_drill": 0.4,
             "microvia_diameter": 0.3, "microvia_drill": 0.1, "diff_pair_gap": 0.25, "diff_pair_width": 0.2,
             "diff_pair_via_gap": 0.25, "wire_width": 6, "bus_width": 12, "line_style": 0,
             "pcb_color": "rgba(0, 0, 0, 0.000)", "schematic_color": "rgba(0, 0, 0, 0.000)", "priority": 0},
            {"name": "Power", "clearance": 0.25, "track_width": 0.5, "via_diameter": 0.8, "via_drill": 0.4,
             "microvia_diameter": 0.3, "microvia_drill": 0.1, "diff_pair_gap": 0.25, "diff_pair_width": 0.2,
             "diff_pair_via_gap": 0.25, "wire_width": 6, "bus_width": 12, "line_style": 0,
             "pcb_color": "rgba(0, 0, 0, 0.000)", "schematic_color": "rgba(0, 0, 0, 0.000)", "priority": 1}],
            "meta": {"version": 3},
            "netclass_patterns": [{"netclass": "RF", "pattern": "RF_ANT"},
                                  {"netclass": "Power", "pattern": "+5V"},
                                  {"netclass": "Power", "pattern": "+3V3"}]},
    }
    with open(os.path.join(OUT, NAME + ".kicad_pro"), "w") as fh:
        json.dump(pro, fh, indent=2)
    with open(os.path.join(OUT, "model.json"), "w") as fh:
        json.dump(dict(model, vias=vias), fh)
    print("ok", len(footprints), "fp", sum(len(t[3]) - 1 for t in tracks), "seg", len(vias), "vias")
