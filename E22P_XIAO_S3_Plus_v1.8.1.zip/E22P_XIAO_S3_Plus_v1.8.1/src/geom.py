import numpy as np, math
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

RES = 0.025  # mm/px

class Canvas:
    def __init__(self, BW, BH):
        self.W, self.H = int(math.ceil(BW / RES)) + 1, int(math.ceil(BH / RES)) + 1
    def new(self):
        return Image.new("1", (self.W, self.H), 0)
    def P(self, x, y):
        return (x / RES, y / RES)

def draw_pad(d, p, ax, ay, grow=0.0):
    ox, oy = p.get("doff") or (0, 0)
    x, y = ax + p["x"] + ox, ay + p["y"] + oy
    w, h = p["w"] + 2 * grow, p["h"] + 2 * grow
    S = 1 / RES
    if p["shape"] == "circle":
        r = w / 2
        d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=1)
    elif p["shape"] == "oval":
        if w >= h:
            r = h / 2
            d.rectangle([(x - w / 2 + r) * S, (y - r) * S, (x + w / 2 - r) * S, (y + r) * S], fill=1)
            for cx in (x - w / 2 + r, x + w / 2 - r):
                d.ellipse([(cx - r) * S, (y - r) * S, (cx + r) * S, (y + r) * S], fill=1)
        else:
            r = w / 2
            d.rectangle([(x - r) * S, (y - h / 2 + r) * S, (x + r) * S, (y + h / 2 - r) * S], fill=1)
            for cy in (y - h / 2 + r, y + h / 2 - r):
                d.ellipse([(x - r) * S, (cy - r) * S, (x + r) * S, (cy + r) * S], fill=1)
    else:
        d.rectangle([(x - w / 2) * S, (y - h / 2) * S, (x + w / 2) * S, (y + h / 2) * S], fill=1)

def draw_seg(d, a, b, w):
    S = 1 / RES
    r = w / 2
    d.line([a[0] * S, a[1] * S, b[0] * S, b[1] * S], fill=1, width=max(1, int(round(w * S))))
    for c in (a, b):
        d.ellipse([(c[0] - r) * S, (c[1] - r) * S, (c[0] + r) * S, (c[1] + r) * S], fill=1)

def draw_circle(d, c, r):
    S = 1 / RES
    d.ellipse([(c[0] - r) * S, (c[1] - r) * S, (c[0] + r) * S, (c[1] + r) * S], fill=1)

def pad_on(p, layer):
    if p["kind"] == "np_thru_hole": return False
    if p["kind"] == "thru_hole": return True
    return layer in p["layers"]

def copper_items(model):
    """lista (layer, net, drawfn) dla miedzi (bez stref)"""
    items = []
    for F in model["footprints"]:
        ax, ay = F["at"]
        for p in F["pads"]:
            for L in ("F.Cu", "B.Cu"):
                if pad_on(p, L):
                    items.append((L, p["net"] or "__nc_%s_%s" % (F["ref"], p["num"]),
                                  ("pad", p, ax, ay)))
    for (L, w, net, pts) in model["tracks"]:
        for a, b in zip(pts, pts[1:]):
            items.append((L, net, ("seg", a, b, w)))
    for (x, y, s, dr, net) in model["vias"]:
        for L in ("F.Cu", "B.Cu"):
            items.append((L, net, ("circ", (x, y), s / 2)))
    return items

def render(cv, items, layer, net_filter=None, grow=0.0):
    img = cv.new(); d = ImageDraw.Draw(img)
    for (L, net, it) in items:
        if L != layer: continue
        if net_filter is not None and not net_filter(net): continue
        if it[0] == "pad": draw_pad(d, it[1], it[2], it[3], grow)
        elif it[0] == "seg": draw_seg(d, it[1], it[2], it[3] + 2 * grow)
        else: draw_circle(d, it[1], it[2] + grow)
    return np.array(img, dtype=bool)

def board_mask(cv, model):
    img = cv.new(); d = ImageDraw.Draw(img)
    S = 1 / RES
    BW, BH = model["BW"], model["BH"]
    nw, nd = model["notch"]
    poly = [(0, 0), (BW / 2 - nw / 2, 0), (BW / 2 - nw / 2, nd), (BW / 2 + nw / 2, nd), (BW / 2 + nw / 2, 0),
            (BW, 0), (BW, BH), (0, BH)]
    d.polygon([(x * S, y * S) for x, y in poly], fill=1)
    x0, y0, x1, y1, r = model["cut"]
    d.rounded_rectangle([x0 * S, y0 * S, x1 * S, y1 * S], radius=r * S, fill=0)
    return np.array(img, dtype=bool)

def holes_mask(cv, model, grow=0.0):
    img = cv.new(); d = ImageDraw.Draw(img)
    for F in model["footprints"]:
        ax, ay = F["at"]
        for p in F["pads"]:
            if p["drill"]:
                draw_circle(d, (ax + p["x"], ay + p["y"]), p["drill"] / 2 + grow)
    for (x, y, s, dr, net) in model["vias"]:
        draw_circle(d, (x, y), dr / 2 + grow)
    return np.array(img, dtype=bool)

def npth_mask(cv, model, grow=0.0):
    img = cv.new(); d = ImageDraw.Draw(img)
    for F in model["footprints"]:
        ax, ay = F["at"]
        for p in F["pads"]:
            if p["kind"] == "np_thru_hole":
                draw_circle(d, (ax + p["x"], ay + p["y"]), p["drill"] / 2 + grow)
    return np.array(img, dtype=bool)

def poly_mask(cv, pts):
    img = cv.new(); d = ImageDraw.Draw(img)
    d.polygon([(x / RES, y / RES) for x, y in pts], fill=1)
    return np.array(img, dtype=bool)

def disk(r_mm):
    r = int(round(r_mm / RES))
    y, x = np.ogrid[-r:r + 1, -r:r + 1]
    return (x * x + y * y) <= r * r

def dilate(m, r_mm):
    if r_mm <= 0: return m
    # EDT szybciej niż binary_dilation dla dużych r
    return ndi.distance_transform_edt(~m) * RES <= r_mm

def erode(m, r_mm):
    return ~dilate(~m, r_mm)

CLR = {"default": 0.2, "+5V": 0.25, "+3V3": 0.25, "RF_ANT": 0.2}
def clr_of(net): return CLR.get(net, CLR["default"])

def fill_zones(cv, model, items, board):
    """symulacja wypełnienia stref (pady pełne, bez odciążeń termicznych)"""
    edge_keep = erode(board, 0.3)
    npth = npth_mask(cv, model, 0.25)
    fills = {}
    zs = sorted(model["zones"], key=lambda z: -z["priority"])
    for z in zs:
        L, net = z["layer"], z["net"]
        reg = poly_mask(cv, z["pts"]) & edge_keep & ~npth
        # inne sieci + odstęp (osobno dla klas)
        for c in sorted(set(CLR.values())):
            others = render(cv, items, L, lambda n, c=c: n != net and max(clr_of(n), 0.2) == c)
            reg &= ~dilate(others, c)
        # wyższy priorytet innych sieci
        for (L2, net2), fm in fills.items():
            if L2 == L and net2 != net:
                reg &= ~dilate(fm, 0.2)
        # min. grubość
        reg = dilate(erode(reg, 0.125), 0.125) & reg
        # usuwanie wysp nie połączonych z miedzią tej sieci
        own = render(cv, items, L, lambda n: n == net)
        lab, nl = ndi.label(reg | own)
        keep = np.unique(lab[own]); keep = keep[keep > 0]
        reg = np.isin(lab, keep) & reg
        key = (L, net)
        fills[key] = fills.get(key, np.zeros_like(reg)) | reg
    return fills
