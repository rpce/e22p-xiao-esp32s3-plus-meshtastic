import numpy as np, math
import geom as G

def make_stitching(model):
    cv = G.Canvas(model["BW"], model["BH"])
    items = G.copper_items(model)
    board = G.board_mask(cv, model)
    nongnd = np.zeros_like(board)
    anypad = np.zeros_like(board)
    for L in ("F.Cu", "B.Cu"):
        nongnd |= G.render(cv, items, L, lambda n: n != "GND")
    for F in model["footprints"]:
        ax, ay = F["at"]
        from PIL import ImageDraw
    padimg = cv.new(); d = G.ImageDraw.Draw(padimg)
    for F in model["footprints"]:
        ax, ay = F["at"]
        for p in F["pads"]:
            if p["kind"] != "np_thru_hole":
                G.draw_pad(d, p, ax, ay)
    anypad = np.array(padimg, dtype=bool)
    d_ng = G.ndi.distance_transform_edt(~nongnd) * G.RES
    d_pad = G.ndi.distance_transform_edt(~anypad) * G.RES
    d_edge = G.ndi.distance_transform_edt(board) * G.RES
    d_npth = G.ndi.distance_transform_edt(~G.npth_mask(cv, model)) * G.RES
    d_hole = G.ndi.distance_transform_edt(~G.holes_mask(cv, model)) * G.RES
    v5 = G.poly_mask(cv, model["v5_poly"])
    v5 = G.dilate(v5, 0.6)

    R = 0.3  # promień przelotki 0.6/0.3
    def ok(x, y, placed, mind=1.1):
        i, j = int(round(y / G.RES)), int(round(x / G.RES))
        if i < 0 or j < 0 or i >= board.shape[0] or j >= board.shape[1]: return False
        if not board[i, j]: return False
        if d_edge[i, j] < R + 0.5: return False
        if d_ng[i, j] < R + 0.25: return False
        if d_pad[i, j] < R + 0.25: return False
        if d_npth[i, j] < 1.6 + 0.6: return False
        if d_hole[i, j] < 0.55: return False
        if v5[i, j]: return False
        for (px, py) in placed:
            if (px - x) ** 2 + (py - y) ** 2 < mind * mind: return False
        return True

    placed = []
    # 1) płot wzdłuż toru RF (obie strony), co 1.3 mm
    path = model["rf"]["path"]
    off = 0.6 + 0.2 + 0.4  # pół toru + przerwa + odstęp
    for a, b in zip(path, path[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
        nx, ny = -uy, ux
        n = int(L / 1.3)
        for k in range(n + 1):
            t = k * L / max(n, 1)
            for s in (-1, 1):
                x, y = a[0] + ux * t + s * nx * off, a[1] + uy * t + s * ny * off
                if ok(x, y, placed, 1.0): placed.append((x, y))
    # 2) obwiednia przelotek pinu 21 i złącza SMA
    for c, rr in ((path[0], 1.35), (path[-1], 1.35)):
        for k in range(12):
            a = 2 * math.pi * k / 12
            x, y = c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)
            if ok(x, y, placed, 0.95): placed.append((x, y))
    # 3) siatka po całej płytce (gęściej pod modułem i przy SMA)
    for y in np.arange(1.2, model["BH"], 2.5):
        for x in np.arange(1.2, model["BW"], 2.5):
            if ok(x, y, placed, 1.6): placed.append((float(x), float(y)))
    return placed
