#!/usr/bin/env python3
# STL wspornika (odpowiednik wspornik_sma.scad) – bez OpenSCAD-a
import math, sys
import numpy as np

BW, WALL_T, WALL_UP, WALL_DN = 40.0, 3.0, 8.0, 6.0
HOLE_D, AXIS_Z = 6.6, 0.4
LUG_W, LUG_L, LUG_T, SCREW_D = 9.0, 7.0, 3.0, 3.3
RIB_T = 2.0
N = 96

tris = []

def add(a, b, c, want):
    a, b, c = map(np.asarray, (a, b, c))
    n = np.cross(b - a, c - a)
    if np.dot(n, want) < 0:
        b, c = c, b
    tris.append((a, b, c))

def plate_with_hole(rect, hc, r, to3, ext, axis_n):
    """rect=(u0,u1,v0,v1) w 2D, otwór (hc,r); to3(u,v,w)->xyz; ext=(w0,w1); axis_n = wektor normalny +w"""
    u0, u1, v0, v1 = rect
    cu, cv = hc
    corners = [(u1, v1), (u0, v1), (u0, v0), (u1, v0)]
    angs = sorted(set([2 * math.pi * k / N for k in range(N)] +
                      [math.atan2(y - cv, x - cu) % (2 * math.pi) for x, y in corners]))
    def ray(a):
        dx, dy = math.cos(a), math.sin(a)
        ts = []
        if dx > 1e-12: ts.append((u1 - cu) / dx)
        if dx < -1e-12: ts.append((u0 - cu) / dx)
        if dy > 1e-12: ts.append((v1 - cv) / dy)
        if dy < -1e-12: ts.append((v0 - cv) / dy)
        t = min(ts)
        return (cu + dx * t, cv + dy * t)
    C = [(cu + r * math.cos(a), cv + r * math.sin(a)) for a in angs]
    R = [ray(a) for a in angs]
    w0, w1 = ext
    an = np.asarray(axis_n, float)
    m = len(angs)
    for i in range(m):
        j = (i + 1) % m
        for w, s in ((w0, -1), (w1, 1)):          # dekle
            p = [to3(*C[i], w), to3(*C[j], w), to3(*R[j], w), to3(*R[i], w)]
            add(p[0], p[1], p[2], s * an); add(p[0], p[2], p[3], s * an)
        # ścianka otworu (normalna do osi otworu)
        a0, a1 = to3(*C[i], w0), to3(*C[j], w0)
        b0, b1 = to3(*C[i], w1), to3(*C[j], w1)
        mid = to3((C[i][0] + C[j][0]) / 2, (C[i][1] + C[j][1]) / 2, w0)
        ctr = to3(cu, cv, w0)
        want = np.asarray(ctr) - np.asarray(mid)
        add(a0, a1, b1, want); add(a0, b1, b0, want)
    # zewnętrzne boki prostokąta (te same punkty co dekle – bez połączeń T)
    cen = to3((u0 + u1) / 2, (v0 + v1) / 2, w0)
    for i in range(m):
        j = (i + 1) % m
        p, q = R[i], R[j]
        a0, a1, b0, b1 = to3(*p, w0), to3(*q, w0), to3(*p, w1), to3(*q, w1)
        mid = to3((p[0] + q[0]) / 2, (p[1] + q[1]) / 2, w0)
        want = np.asarray(mid) - np.asarray(cen)
        if abs(p[0] - q[0]) < 1e-9 and abs(p[1] - q[1]) < 1e-9: continue
        add(a0, a1, b1, want); add(a0, b1, b0, want)

# ścianka: profil w (x,z), wyciągnięcie po y od -WALL_T do 0
plate_with_hole((0, BW, -WALL_DN, WALL_UP), (BW / 2, AXIS_Z), HOLE_D / 2,
                lambda u, v, w: (u, w, v), (-WALL_T, 0.0), (0, 1, 0))
# łapy: profil w (x,y), wyciągnięcie po z 0..LUG_T
plate_with_hole((0, LUG_W, -1, LUG_L), (3.5, 3.5), SCREW_D / 2, lambda u, v, w: (u, v, w), (0, LUG_T), (0, 0, 1))
plate_with_hole((BW - LUG_W, BW, -1, LUG_L), (BW - 3.5, 3.5), SCREW_D / 2, lambda u, v, w: (u, v, w),
                (0, LUG_T), (0, 0, 1))
# żebra: trójkąt w (y,z), wyciągnięcie po x
def rib(x0):
    T = [(-0.5, LUG_T), (5.0, LUG_T), (-0.5, WALL_UP)]
    P0 = [(x0, y, z) for y, z in T]; P1 = [(x0 + RIB_T, y, z) for y, z in T]
    add(*P0, (-1, 0, 0)); add(*P1, (1, 0, 0))
    c = np.mean(np.array(P0 + P1), axis=0)
    for i in range(3):
        j = (i + 1) % 3
        mid = (np.asarray(P0[i]) + np.asarray(P0[j]) + np.asarray(P1[i]) + np.asarray(P1[j])) / 4
        add(P0[i], P0[j], P1[j], mid - c); add(P0[i], P1[j], P1[i], mid - c)
rib(6.8); rib(BW - 6.8 - RIB_T)

out = sys.argv[1]
with open(out, "w") as fh:
    fh.write("solid wspornik_sma\n")
    for a, b, c in tris:
        n = np.cross(b - a, c - a); L = np.linalg.norm(n); n = n / L if L else n
        fh.write("facet normal %g %g %g\n outer loop\n" % tuple(n))
        for p in (a, b, c):
            fh.write("  vertex %.4f %.4f %.4f\n" % tuple(p))
        fh.write(" endloop\nendfacet\n")
    fh.write("endsolid wspornik_sma\n")
print(len(tris), "trójkątów")
