// Wspornik gniazda SMA Amphenol 132289 do płytki E22P+XIAO (40 mm szer.)
// Układ: płytka w płaszczyźnie XY, górna powierzchnia z=0, krawędź płytki y=0, płytka w +y.
// Drukować ścianką na stole (ścianka leży płasko), PETG, 100% wypełnienia ścianki lub min. 4 obrysy.

BW      = 40;    // szerokość płytki
WALL_T  = 3.0;   // grubość ścianki (gwint zajęty: 3.0 + podkładka 0.5 + nakrętka 1.6; zostaje ok. 4.5 mm na antenę)
WALL_UP = 8;     // ścianka nad płytką
WALL_DN = 6;     // ścianka pod górną powierzchnią płytki
HOLE_D  = 6.6;   // otwór na gwint 1/4-36 (Ø6.35)
AXIS_Z  = 0.4;   // oś gniazda nad górną powierzchnią płytki (pin środkowy leży na miedzi)
LUG_W   = 9;     // łapy
LUG_L   = 7;
LUG_T   = 3;
SCREW_D = 3.3;   // M3
H1 = [3.5, 3.5];
H2 = [BW - 3.5, 3.5];
RIB_T = 2;

$fn = 64;

difference() {
  union() {
    // ścianka przed krawędzią płytki
    translate([0, -WALL_T, -WALL_DN]) cube([BW, WALL_T, WALL_DN + WALL_UP]);
    // łapy na płytce
    translate([0, -1, 0])          cube([LUG_W, LUG_L + 1, LUG_T]);
    translate([BW - LUG_W, -1, 0]) cube([LUG_W, LUG_L + 1, LUG_T]);
    // żebra (poza łbami śrub)
    for (x = [6.8, BW - 6.8 - RIB_T])
      translate([x, 0, LUG_T]) rotate([90, 0, 90])
        linear_extrude(RIB_T) polygon([[-0.5, 0], [5, 0], [-0.5, WALL_UP - LUG_T]]);
  }
  // otwór na gwint
  translate([BW / 2, 1, AXIS_Z]) rotate([90, 0, 0]) cylinder(d = HOLE_D, h = WALL_T + 3);
  // otwory M3
  for (p = [H1, H2]) translate([p[0], p[1], -1]) cylinder(d = SCREW_D, h = LUG_T + 2);
}
