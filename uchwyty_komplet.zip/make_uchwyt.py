#!/usr/bin/env python3
# STL uchwytu-grzebienia (odpowiednik uchwyt_grzebien.scad), z prostopadłościanów – bez OpenSCAD-a.
import sys, numpy as np

H, Z0, PITCH, SLOT, DEPTH, BACK, SIDE, JAW, BW, CLR = 50, 10, 3, 1.7, 6.2, 2.8, 2.7, 10, 40, 0.3
HOLE = 3.4
H3, H4 = (3.5, 2.5), (37.2, 3.0)
LUG_W, LUG_Y0, LUG_Y1, LUG_T, SLOT_L, SD = 22, -6, 15, 4, 11, 3.6
E = 0.02   # zakładka między bryłami (slicer łączy nakładające się bryły)

def boxes_for(offset):
    B = []
    slots = [z for z in np.arange(Z0 + offset, H - SLOT - 1.5 + 1e-6, PITCH)]
    for left in (True, False):
        x0 = -CLR - SIDE if left else BW - JAW
        x1 = JAW if left else BW + CLR + SIDE
        sx0, sx1 = (-CLR, JAW) if left else (BW - JAW, BW + CLR)      # obszar szpar (wnętrze szczęki)
        hx, hy = H3 if left else H4
        # ściana boczna i tylna
        if left: B.append((x0, -CLR + E, 0, DEPTH + BACK, 0, H))
        else:    B.append((BW + CLR - E, x1, 0, DEPTH + BACK, 0, H))
        B.append((x0, x1, DEPTH - E, DEPTH + BACK, 0, H))
        # przegrody (pełne poziomy między szparami) z kwadratowym otworem M3
        zs = [0.0]
        for s in slots: zs += [s, s + SLOT]
        zs.append(float(H))
        for za, zb in zip(zs[0::2], zs[1::2]):
            hx0, hx1, hy0, hy1 = hx - HOLE / 2, hx + HOLE / 2, hy - HOLE / 2, hy + HOLE / 2
            B += [(sx0, hx0 + E, 0, DEPTH, za, zb), (hx1 - E, sx1, 0, DEPTH, za, zb),
                  (hx0, hx1, 0, hy0 + E, za, zb), (hx0, hx1, hy1 - E, DEPTH, za, zb)]
        # łapa z otworem podłużnym (prostokątnym) wzdłuż y
        lx0 = -CLR - SIDE - LUG_W if left else BW + CLR + SIDE
        cx = lx0 + LUG_W / 2
        oy0, oy1 = LUG_Y0 + 5 - SD / 2, LUG_Y0 + 5 + SLOT_L - SD - SD / 2 + SD
        ex0, ex1 = (lx0, x0 + E) if left else (x1 - E, lx0 + LUG_W)
        B += [(lx0 if left else ex0, cx - SD / 2 + E, LUG_Y0, LUG_Y1, 0, LUG_T),
              (cx + SD / 2 - E, ex1 if left else lx0 + LUG_W, LUG_Y0, LUG_Y1, 0, LUG_T),
              (cx - SD / 2, cx + SD / 2, LUG_Y0, oy0 + E, 0, LUG_T),
              (cx - SD / 2, cx + SD / 2, oy1 - E, LUG_Y1, 0, LUG_T)]
    B.append((-CLR - SIDE, BW + CLR + SIDE, DEPTH, DEPTH + BACK, 0, 4))     # belka tylna
    return B, slots

def tri_box(b):
    x0, x1, y0, y1, z0, z1 = b
    P = np.array([[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0],
                  [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]])
    Q = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    T = []
    for a, b_, c, d in Q:
        T += [(P[a], P[b_], P[c]), (P[a], P[c], P[d])]
    return T

def gusset(left):
    # trójkątne żebro między łapą a ścianą boczną
    xw = -CLR - SIDE if left else BW + CLR + SIDE
    xo = xw - 7 if left else xw + 7
    y0, y1 = 4.0, DEPTH + BACK          # z tyłu – poza zasięgiem modułu SHT31 (y płytki <= 67.5)
    A = [(xw, LUG_T), (xo, LUG_T), (xw, 18)]
    P0 = [np.array([x, y0, z]) for x, z in A]; P1 = [np.array([x, y1, z]) for x, z in A]
    T = []
    # orientacja liczona tak, by normalne były na zewnątrz
    T.append((P0[0], P0[1], P0[2]) if left else (P0[0], P0[2], P0[1]))
    T.append((P1[0], P1[2], P1[1]) if left else (P1[0], P1[1], P1[2]))
    for i in range(3):
        j = (i + 1) % 3
        q = (P0[i], P0[j], P1[j], P1[i]) if left else (P0[i], P1[i], P1[j], P0[j])
        T += [(q[0], q[1], q[2]), (q[0], q[2], q[3])]
    return T

def write(fname, offset):
    B, slots = boxes_for(offset)
    T = []
    for b in B: T += tri_box(b)
    T += gusset(True) + gusset(False)
    with open(fname, "w") as fh:
        fh.write("solid uchwyt\n")
        for a, b, c in T:
            n = np.cross(b - a, c - a); L = np.linalg.norm(n); n = n / L if L else n
            fh.write("facet normal %g %g %g\n outer loop\n" % tuple(n))
            for p in (a, b, c): fh.write("  vertex %.3f %.3f %.3f\n" % tuple(p))
            fh.write(" endloop\nendfacet\n")
        fh.write("endsolid uchwyt\n")
    return slots

if __name__ == "__main__":
    for off in (0, 1, 2):
        s = write("uchwyt_grzebien_offset%d.stl" % off, off)
        print("offset", off, "szpary (dół laminatu, mm):", [round(float(z), 1) for z in s])

# ======================= UCHWYT PRZEDNI (chwyta boczne krawędzie przy SMA) =======================
FL = 10.0          # długość chwytu wzdłuż płytki (od przedniej krawędzi y=0)
FDEP = 6.2         # głębokość szpary w głąb płytki (od boku)
FOUT = 3.5         # zewnętrzna ściana
H1, H2 = (3.5, 3.5), (36.5, 3.5)

def boxes_front(offset):
    B = []
    slots = [z for z in np.arange(Z0 + offset, H - SLOT - 1.5 + 1e-6, PITCH)]
    for left in (True, False):
        if left:
            wx0, wx1 = -CLR - FOUT, -CLR + E                # ściana zewnętrzna
            sx0, sx1 = -CLR, FDEP                           # obszar przegród
            hx, hy = H1
        else:
            wx0, wx1 = BW + CLR - E, BW + CLR + FOUT
            sx0, sx1 = BW - FDEP, BW + CLR
            hx, hy = H2
        B.append((wx0, wx1, 0, FL, 0, H))
        zs = [0.0]
        for s in slots: zs += [s, s + SLOT]
        zs.append(float(H))
        hx0, hx1, hy0, hy1 = hx - HOLE / 2, hx + HOLE / 2, hy - HOLE / 2, hy + HOLE / 2
        for za, zb in zip(zs[0::2], zs[1::2]):
            B += [(sx0, hx0 + E, 0, FL, za, zb), (hx1 - E, sx1, 0, FL, za, zb),
                  (hx0, hx1, 0, hy0 + E, za, zb), (hx0, hx1, hy1 - E, FL, za, zb)]
        # łapa z otworem podłużnym wzdłuż y
        lx0 = -CLR - FOUT - LUG_W if left else BW + CLR + FOUT
        cx = lx0 + LUG_W / 2
        ly0, ly1 = -5.0, FL + 10.0
        oy0, oy1 = ly0 + 3.2, ly0 + 3.2 + SLOT_L
        ex = (-CLR - FOUT + E) if left else (BW + CLR + FOUT - E)
        B += [(lx0, cx - SD / 2 + E, ly0, ly1, 0, LUG_T) if left else (ex, cx - SD / 2 + E, ly0, ly1, 0, LUG_T),
              (cx + SD / 2 - E, ex, ly0, ly1, 0, LUG_T) if left else (cx + SD / 2 - E, lx0 + LUG_W, ly0, ly1, 0, LUG_T),
              (cx - SD / 2, cx + SD / 2, ly0, oy0 + E, 0, LUG_T),
              (cx - SD / 2, cx + SD / 2, oy1 - E, ly1, 0, LUG_T)]
    B.append((-CLR - FOUT, BW + CLR + FOUT, FL - 3.0, FL, 0, 4))     # belka łącząca (pod płytką, z dala od SMA)
    return B, slots

def gusset_front(left):
    xw = -CLR - FOUT if left else BW + CLR + FOUT
    xo = xw - 7 if left else xw + 7
    A = [(xw, LUG_T), (xo, LUG_T), (xw, 18)]
    P0 = [np.array([x, 2.0, z]) for x, z in A]; P1 = [np.array([x, FL, z]) for x, z in A]
    T = [(P0[0], P0[1], P0[2]) if left else (P0[0], P0[2], P0[1]),
         (P1[0], P1[2], P1[1]) if left else (P1[0], P1[1], P1[2])]
    for i in range(3):
        j = (i + 1) % 3
        q = (P0[i], P0[j], P1[j], P1[i]) if left else (P0[i], P1[i], P1[j], P0[j])
        T += [(q[0], q[1], q[2]), (q[0], q[2], q[3])]
    return T

def write_front(fname, offset):
    B, slots = boxes_front(offset)
    T = []
    for b in B: T += tri_box(b)
    T += gusset_front(True) + gusset_front(False)
    with open(fname, "w") as fh:
        fh.write("solid uchwyt_przod\n")
        for a, b, c in T:
            n = np.cross(b - a, c - a); L = np.linalg.norm(n); n = n / L if L else n
            fh.write("facet normal %g %g %g\n outer loop\n" % tuple(n))
            for p in (a, b, c): fh.write("  vertex %.3f %.3f %.3f\n" % tuple(p))
            fh.write(" endloop\nendfacet\n")
        fh.write("endsolid uchwyt_przod\n")
    return slots

if __name__ == "__main__":
    for off in (0, 1, 2):
        write_front("uchwyt_przod_offset%d.stl" % off, off)
    print("uchwyty przednie: gotowe")

# ======================= KLOCEK SMA (na nakrętkę 132289), przykręcany do płytki przez H1/H2 =======================
# Układ płytki: krawędź przednia y = 0 (płytka w +y), góra laminatu z = 0, oś gniazda z = 0.4, x = 0..40.
AXZ, NUT_AF, NUT_T, THR = 0.4, 8.15, 1.65, 6.6
Y_REAR, Y_NUT, Y_FRONT = -0.10, -0.10 - NUT_T, -0.10 - NUT_T - 2.0      # tył klocka / kieszeń nakrętki / ścianka
ZB, ZT = -6.0, 7.0
def boxes_sma():
    B = []
    px0, px1 = 20 - NUT_AF / 2, 20 + NUT_AF / 2        # kieszeń sześciokątna (płaskie boki pionowo), otwarta od góry
    pz0 = AXZ - 4.7                                     # pod dolnym narożnikiem nakrętki
    ux0, ux1 = 20 - THR / 2, 20 + THR / 2               # wycięcie U na gwint w ściance
    uz0 = AXZ - THR / 2
    # część z kieszenią (Y_NUT..Y_REAR)
    B += [(0, px0 + E, Y_NUT, Y_REAR, ZB, ZT), (px1 - E, 40, Y_NUT, Y_REAR, ZB, ZT), (px0, px1, Y_NUT, Y_REAR, ZB, pz0 + E)]
    # ścianka przednia (Y_FRONT..Y_NUT) z wycięciem U
    B += [(0, ux0 + E, Y_FRONT, Y_NUT + E, ZB, ZT), (ux1 - E, 40, Y_FRONT, Y_NUT + E, ZB, ZT),
          (ux0, ux1, Y_FRONT, Y_NUT + E, ZB, uz0 + E)]
    # łapy na płytce z otworami M3 (H1, H2)
    for hx, lx0, lx1 in ((3.5, 0, 9), (36.5, 31, 40)):
        h0, h1 = hx - 1.65, hx + 1.65
        B += [(lx0, h0 + E, Y_REAR - E, 7, 0, 3), (h1 - E, lx1, Y_REAR - E, 7, 0, 3),
              (h0, h1, Y_REAR - E, 3.5 - 1.65 + E, 0, 3), (h0, h1, 3.5 + 1.65 - E, 7, 0, 3)]
    return B

def write_boxes(fname, B, name):
    T = []
    for b in B: T += tri_box(b)
    with open(fname, "w") as fh:
        fh.write("solid %s\n" % name)
        for a, b, c in T:
            n = np.cross(b - a, c - a); L = np.linalg.norm(n); n = n / L if L else n
            fh.write("facet normal %g %g %g\n outer loop\n" % tuple(n))
            for p in (a, b, c): fh.write("  vertex %.3f %.3f %.3f\n" % tuple(p))
            fh.write(" endloop\nendfacet\n")
        fh.write("endsolid %s\n" % name)

# przedni grzebień v2: szczęki 8..18 mm od przedniej krawędzi, głębokość 5 mm, bez otworów (H1/H2 zajmuje klocek SMA)
def boxes_front2(offset, y0=8.0, y1=18.0, dep=5.0):
    B = []
    slots = [z for z in np.arange(Z0 + offset, H - SLOT - 1.5 + 1e-6, PITCH)]
    zs = [0.0]
    for s in slots: zs += [s, s + SLOT]
    zs.append(float(H))
    for left in (True, False):
        if left: wx0, wx1, sx0, sx1 = -CLR - FOUT, -CLR + E, -CLR, dep
        else:    wx0, wx1, sx0, sx1 = BW + CLR - E, BW + CLR + FOUT, BW - dep, BW + CLR
        B.append((wx0, wx1, y0, y1, 0, H))
        for za, zb in zip(zs[0::2], zs[1::2]):
            B.append((sx0, sx1, y0, y1, za, zb))
        lx0 = -CLR - FOUT - LUG_W if left else BW + CLR + FOUT
        cx = lx0 + LUG_W / 2
        ly0, ly1 = y0 - 5, y1 + 5
        oy0, oy1 = ly0 + 3.2, ly0 + 3.2 + SLOT_L
        ex = (-CLR - FOUT + E) if left else (BW + CLR + FOUT - E)
        a0, a1 = (lx0, ex) if left else (ex, lx0 + LUG_W)
        B += [(a0, cx - SD / 2 + E, ly0, ly1, 0, LUG_T), (cx + SD / 2 - E, a1, ly0, ly1, 0, LUG_T),
              (cx - SD / 2, cx + SD / 2, ly0, oy0 + E, 0, LUG_T), (cx - SD / 2, cx + SD / 2, oy1 - E, ly1, 0, LUG_T)]
    B.append((-CLR - FOUT, BW + CLR + FOUT, y1 - 3.0, y1, 0, 4))
    return B, slots

if __name__ == "__main__":
    write_boxes("klocek_sma.stl", boxes_sma(), "klocek_sma")
    for off in (0, 1, 2):
        write_boxes("uchwyt_przod_offset%d.stl" % off, boxes_front2(off)[0], "uchwyt_przod")
    print("klocek SMA + przednie v2: gotowe")

# ======================= KLOCEK SMA v2: pełny otwór czołowy, nakrętka z przodu dociska ściankę do kołnierza ===========
WALL2 = 2.5
def boxes_sma2():
    B = []
    y1, y0 = -0.10, -0.10 - WALL2
    # otwór na gwint ~ okrągły (ośmiokąt z prostopadłościanów), Ø6.6
    r = THR / 2
    hx0, hx1 = 20 - r, 20 + r
    # pełne części wokół otworu
    B += [(0, hx0 + E, y0, y1, ZB, ZT), (hx1 - E, 40, y0, y1, ZB, ZT),
          (hx0, hx1, y0, y1, ZB, AXZ - r + E), (hx0, hx1, y0, y1, AXZ + r - E, ZT)]
    # wypełnienie narożników otworu (żeby był bliżej okręgu: ośmiokąt)
    c = r * (1 - 1 / 2 ** 0.5)
    for sx in (-1, 1):
        for sz in (-1, 1):
            xa, xb = (hx0, hx0 + c) if sx < 0 else (hx1 - c, hx1)
            za, zb = (AXZ - r, AXZ - r + c) if sz < 0 else (AXZ + r - c, AXZ + r)
            B.append((xa, xb, y0, y1, za, zb))
    for hx, lx0, lx1 in ((3.5, 0, 9), (36.5, 31, 40)):
        h0, h1 = hx - 1.65, hx + 1.65
        B += [(lx0, h0 + E, y1 - E, 7, 0, 3), (h1 - E, lx1, y1 - E, 7, 0, 3),
              (h0, h1, y1 - E, 3.5 - 1.65 + E, 0, 3), (h0, h1, 3.5 + 1.65 - E, 7, 0, 3)]
    return B

if __name__ == "__main__":
    write_boxes("klocek_sma.stl", boxes_sma2(), "klocek_sma")
    print("klocek SMA v2 (otwór czołowy): gotowy")
