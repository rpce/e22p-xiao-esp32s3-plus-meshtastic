// Uchwyt-grzebień tylnej krawędzi płytki E22P+XIAO (v1.8.1, 40 x 73 mm) do dna puszki.
// Dwie szczęki chwytają tylne narożniki płytki (środek wolny pod USB-C XIAO i radiator),
// szpary co 3 mm; OFFSET = 0 / 1 / 2 daje razem wysokości co 1 mm od 10 do 48 mm.
// Pionowe otwory M3 trafiają w otwory H3 i H4 płytki – długa śruba M3 (lub pręt) blokuje płytkę.
// Układ: x = szerokość płytki (0..40), y = od przedniej ściany szczęk (0) do tyłu, z = od dna.
// Druk: tylną ścianą (y = 9) do stołu – przegrody drukują się pionowo, bez podpór. PETG, 4 obrysy.

OFFSET   = 0;      // 0, 1 lub 2
H        = 50;     // wysokość
Z0       = 10;     // najniższa szpara (dół laminatu) przy OFFSET = 0
PITCH    = 3;      // skok szpar
SLOT     = 1.7;    // szpara na laminat 1.6 mm
DEPTH    = 6.2;    // głębokość szpary (krawędź płytki na y = 6.0)
BACK     = 2.8;    // tylna ściana
SIDE     = 2.7;    // boczna ściana
JAW      = 10;     // szerokość chwytu narożnika
BW       = 40;     // szerokość płytki
CLR      = 0.3;    // luz na bokach płytki
H3 = [3.5, 2.5];   // otwór H3 płytki (3.5, 69.5) w układzie uchwytu
H4 = [37.2, 3.0];  // otwór H4 płytki (37.2, 70.0)
HOLE = 3.4;        // M3
LUG_W = 22; LUG_Y0 = -6; LUG_Y1 = 15; LUG_T = 4;   // łapy z otworami podłużnymi
SLOT_L = 11;                                        // długość otworu podłużnego (regulacja odległości od ściany)

$fn = 32;
slots = [for (z = [Z0 + OFFSET : PITCH : H - SLOT - 1.5]) z];

module jaw(left) {
  x0 = left ? -CLR - SIDE : BW - JAW;
  x1 = left ? JAW : BW + CLR + SIDE;
  hx = left ? H3 : H4;
  difference() {
    translate([x0, 0, 0]) cube([x1 - x0, DEPTH + BACK, H]);
    for (z = slots)
      translate([left ? -CLR : BW - JAW - 1, -1, z])
        cube([JAW + CLR + 1, DEPTH + 1, SLOT]);
    translate([hx[0], hx[1], -1]) cylinder(d = HOLE, h = H + 2);
  }
}
module lug(left) {
  x0 = left ? -CLR - SIDE - LUG_W : BW + CLR + SIDE;
  cx = x0 + LUG_W / 2;
  difference() {
    translate([x0 - 0.01, LUG_Y0, 0]) cube([LUG_W + 0.02, LUG_Y1 - LUG_Y0, LUG_T]);
    hull() for (y = [LUG_Y0 + 5, LUG_Y0 + 5 + SLOT_L - 3.6])
      translate([cx, y, -1]) cylinder(d = 3.6, h = LUG_T + 2);
  }
  // żebro usztywniające
  gx = left ? -CLR - SIDE : BW + CLR + SIDE;
  // żebro z tyłu (y >= 4), żeby nie dotykało modułu SHT31 wystającego za prawą krawędź płytki
  hull() {
    translate([gx - (left ? 7 : 0), 4, 0]) cube([7, DEPTH + BACK - 4, LUG_T]);
    translate([gx - (left ? 0.01 : 0), 4, 0]) cube([0.01, DEPTH + BACK - 4, 18]);
  }
}
union() {
  jaw(true); jaw(false); lug(true); lug(false);
  translate([-CLR - SIDE, DEPTH, 0]) cube([BW + 2 * (CLR + SIDE), BACK, 4]);   // belka tylna
}
